<?php

$xml = new DOMDocument();
$xml->load('books.xml');



foreach ($xml->book as $book) {
    if ($book->author == "O'Brien, Tim") {
        echo $book->title . "\n";
    }
}

$xml->save('books.xml');

?>

